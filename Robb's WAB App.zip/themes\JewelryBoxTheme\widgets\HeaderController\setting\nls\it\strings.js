define({
  "group": "Nome",
  "openAll": "Apri tutto nel pannello",
  "dropDown": "Mostra nel menu a discesa",
  "noGroup": "Nessun gruppo di widget impostato.",
  "groupSetLabel": "Imposta proprietà per gruppi di widget"
});