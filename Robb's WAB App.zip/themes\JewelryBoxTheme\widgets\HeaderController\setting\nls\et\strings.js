define({
  "group": "Nimi",
  "openAll": "Ava kõik paneelis",
  "dropDown": "Näita rippmenüüs",
  "noGroup": "Vidina gruppi pole määratud.",
  "groupSetLabel": "Määra vidina gruppide omadused"
});