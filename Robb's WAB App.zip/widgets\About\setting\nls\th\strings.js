define({
  "instruction": "สร้างเนื้อหาที่จะแสดงในวิทเจ็ต",
  "defaultContent": "เพิ่มตัวหนังสือ,ลิงค์,และกราฟฟิคเล็กๆที่นี่",
  "productVersion": "รุ่นของผลิตภัณฑ์: ",
  "kernelVersion": "รุ่นของเคอร์เนล : "
});