define({
  "instruction": "Kurkite turinį, kuris bus rodomas šiame valdiklyje.",
  "defaultContent": "Čia pridėkite teksto, nuorodų ir mažų grafinių elementų.",
  "productVersion": "Produkto versija: ",
  "kernelVersion": "Branduolio versija: "
});