define({
  "_widgetLabel": "אודות"
});