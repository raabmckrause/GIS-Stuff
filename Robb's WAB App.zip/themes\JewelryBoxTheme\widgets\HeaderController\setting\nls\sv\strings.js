define({
  "group": "Namn",
  "openAll": "Öppna alla i panelen",
  "dropDown": "Visa i listmenyn",
  "noGroup": "Det finns ingen angiven widgetgrupp.",
  "groupSetLabel": "Ange widgetgruppens egenskaper"
});