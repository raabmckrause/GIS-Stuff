define({
  "instruction": "إنشاء المحتويات التي ستُعرَض في عنصر واجهة المستخدم.",
  "defaultContent": "أضف نصًا وروابط ورسومات بيانية صغيرة هنا.",
  "productVersion": "إصدار المنتج: ",
  "kernelVersion": "إصدار Kernel "
});