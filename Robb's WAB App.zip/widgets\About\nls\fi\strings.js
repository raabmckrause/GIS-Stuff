define({
  "_widgetLabel": "Tietoja"
});