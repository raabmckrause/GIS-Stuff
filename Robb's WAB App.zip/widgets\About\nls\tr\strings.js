define({
  "_widgetLabel": "Hakkında"
});