define({
  "_widgetLabel": "Despre"
});