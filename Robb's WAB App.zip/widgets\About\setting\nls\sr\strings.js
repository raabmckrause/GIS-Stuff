define({
  "instruction": "Kreirajte sadržaj koji se prikazuje u ovom vidžetu.",
  "defaultContent": "Dodajte tekst, veze i male grafičke prikaze ovde.",
  "productVersion": "Verzija proizvoda: ",
  "kernelVersion": "Verzija jezgra: "
});