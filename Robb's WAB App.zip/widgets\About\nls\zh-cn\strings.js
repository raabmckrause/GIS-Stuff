define({
  "_widgetLabel": "关于"
});