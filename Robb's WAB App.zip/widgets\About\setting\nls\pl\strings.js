define({
  "instruction": "Utwórz zawartość wyświetlaną w tym widżecie.",
  "defaultContent": "Tutaj możesz dodać tekst, łącza oraz niewielkie elementy graficzne.",
  "productVersion": "Wersja produktu: ",
  "kernelVersion": "Wersja jądra systemu: "
});