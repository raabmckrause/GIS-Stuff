define({
  "group": "Navn",
  "openAll": "Åpne alle i panelet",
  "dropDown": "Vis i rullegardinmenyen",
  "noGroup": "Det finnes ikke noe widgetgruppesett.",
  "groupSetLabel": "Angi egenskaper for widgetgrupper"
});