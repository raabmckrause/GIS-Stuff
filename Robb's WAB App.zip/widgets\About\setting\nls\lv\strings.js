define({
  "instruction": "Izveidojiet saturu, kas tiks rādīts šajā logrīkā.",
  "defaultContent": "Šeit pievienojiet tekstu, saites un nelielas grafikas.",
  "productVersion": "Produkta versija: ",
  "kernelVersion": "Kodola versija: "
});