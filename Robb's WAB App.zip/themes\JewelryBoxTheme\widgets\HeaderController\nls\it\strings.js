define({
  "_widgetLabel": "Controller intestazione",
  "signin": "Accedi",
  "signout": "Esci",
  "about": "Info",
  "signInTo": "Accedi a",
  "cantSignOutTip": "Questa funzione non è disponibile in modalità anteprima.",
  "more": "altro"
});