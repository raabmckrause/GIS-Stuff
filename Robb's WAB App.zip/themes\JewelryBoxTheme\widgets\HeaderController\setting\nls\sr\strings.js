define({
  "group": "Naziv",
  "openAll": "Otvori sve u panelu",
  "dropDown": "Prikaži u padajućem meniju",
  "noGroup": "Grupa vidžeta nije postavljena.",
  "groupSetLabel": "Postavi svojstva grupe vidžeta"
});