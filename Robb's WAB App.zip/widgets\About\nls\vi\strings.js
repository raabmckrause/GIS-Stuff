define({
  "_widgetLabel": "Về"
});