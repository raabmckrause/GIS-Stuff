define({
  "_widgetLabel": "เกี่ยวกับ"
});