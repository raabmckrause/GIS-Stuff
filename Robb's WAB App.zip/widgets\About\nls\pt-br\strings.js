define({
  "_widgetLabel": "Sobre"
});