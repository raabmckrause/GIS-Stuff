define({
  "_widgetLabel": "О"
});