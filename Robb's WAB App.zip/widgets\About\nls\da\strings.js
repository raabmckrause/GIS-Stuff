define({
  "_widgetLabel": "Om"
});