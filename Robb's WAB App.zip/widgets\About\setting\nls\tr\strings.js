define({
  "instruction": "Bu araçta görüntülenecek içeriği oluşturun.",
  "defaultContent": "Buraya metin, bağlantılar ve küçük grafikler ekleyin.",
  "productVersion": "Ürün Versiyonu: ",
  "kernelVersion": "Çekirdek Sürümü: "
});