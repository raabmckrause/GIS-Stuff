define({
  "_widgetLabel": "Par"
});