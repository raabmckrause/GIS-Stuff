define({
  "_widgetLabel": "Više o"
});