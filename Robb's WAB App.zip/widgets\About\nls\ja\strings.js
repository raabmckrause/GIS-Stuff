define({
  "_widgetLabel": "情報"
});