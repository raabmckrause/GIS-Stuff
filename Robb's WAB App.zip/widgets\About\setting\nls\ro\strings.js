define({
  "instruction": "Creaţi conţinutul care este afişat în acest widget.",
  "defaultContent": "Adăugaţi aici text, legături şi alte imagini mici.",
  "productVersion": "Versiune produs: ",
  "kernelVersion": "Versiune kernel: "
});