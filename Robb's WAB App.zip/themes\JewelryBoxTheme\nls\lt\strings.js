define({
  "_themeLabel": "Papuošalų dėžutės tema",
  "_layout_default": "Numatytasis maketas",
  "_layout_layout1": "1 maketas",
  "emptyDocablePanelTip": "Paspauskite mygtuką + valdiklio skirtuke, kad įtrauktumėte valdiklį. "
});