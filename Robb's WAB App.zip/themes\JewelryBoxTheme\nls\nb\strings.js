define({
  "_themeLabel": "Smykkeskrintema",
  "_layout_default": "Standard oppsett",
  "_layout_layout1": "Oppsett 1",
  "emptyDocablePanelTip": "Klikk på +-knappen i Widget-kategorien for å legge til en widget. "
});