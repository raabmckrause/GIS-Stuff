define({
  "_widgetLabel": "Apie"
});